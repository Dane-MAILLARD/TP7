import { Component } from '@angular/core';

@Component({
  selector: 'boite',
  templateUrl: './boite.component.html',
  styleUrls: ['./boite.component.scss']
})
export class BoiteComponent {
    tirelire1 : number = 0;
    tirelire2 : number = 0;
    tirelire3 : number = 0;
    
    addMontant() {
      let num = Math.floor(Math.random() *3);
      if(num == 0){
        this.tirelire1  += 100;
      }
      if(num == 1){
        this.tirelire2 += 100;
      }
      if(num == 2){
        this.tirelire3 += 100;
      }

    }

    useMontant1(){
      this.tirelire1 -= this.tirelire1;
    }
    
    useMontant2(){
      this.tirelire2 -= this.tirelire2;
    }

    useMontant3(){
      this.tirelire3 -= this.tirelire3;
    }
}


